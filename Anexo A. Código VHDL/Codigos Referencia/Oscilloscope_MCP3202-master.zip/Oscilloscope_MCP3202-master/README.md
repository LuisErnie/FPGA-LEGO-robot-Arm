# 2-channel FPGA based Digital Oscilloscope
Board : CYCLONE3- EP3C5E144C8

Analog to digital converter(ADC) : MCP3202

Program : Quatus II 13.1 , processing 3.02 or later

Source code : https://github.com/mrkitravee/Oscilloscope_MCP3202

Blogger : http://oscilloscopeproject.blogspot.com

User guide : http://oscilloscopeproject.blogspot.com/2016/05/test1_27.html

Vedio demo : https://www.youtube.com/watch?v=QChHlru5QlQ

#Contact Us


Contact 1: https://www.facebook.com/KitraveeSiwatkittisuk

Contact 2: https://www.facebook.com/jaschatsada.nganiam

Contact 3: https://www.facebook.com/JittipongManus
